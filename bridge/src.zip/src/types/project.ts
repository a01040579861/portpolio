export type ProjectCategory =
  | "ALL"
  | "BACKEND"
  | "FRONTEND"
  | "PUBLISHING"
  | "UI/UX";

export interface ProjectItem {
  id: number;
  title: string;
  image: string; // public 폴더 경로
  category: ProjectCategory;
  description: string;
  techStack: string[];
  period: string;
}
